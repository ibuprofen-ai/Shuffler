<?php
session_start(); // Starting the session
session_destroy(); // Destroying the session
header('Location: shufflerHome.html'); // Redirect to home page signed out
exit(); // Exit the script
?> 