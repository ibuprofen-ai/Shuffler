<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>shuffler_privacy</title>
    <link rel="stylesheet" href="shuffler.css">
</head>
<body>
    <header>
        <div id="logo-div">
        <img id="logo" src="Images/Shuffler.png" alt="Logo">
        <h1>Shuffler</h1>
        </div>
        <nav>
            <a href="shufflerHome.php">Home</a>
            <a href="shufflerAccount.php">Account</a>
            <a href="shufflerAbout.php">How It Works</a>
            <a href="shufflersos@gmail.com">Contact/Support</a>
        </nav>
        <form id="logout-form" action="shufflerLogout.php" method="post">
            <button type="submit" name="signOut" id="sign_out">Sign Out</button>
        </form>
    </header>

    <h1 class="privacy">Privacy Policy</h1>
    <p class="privacy">
        At Shuffler, we are committed to protecting your privacy. This Privacy Policy outlines how we collect, use, and safeguard your personal information when you use our website ("Shuffler," "we," "our," or "us"). By accessing or using our website, you consent to the practices described in this policy.

        1. Information We Collect
        
        We may collect the following types of information:
        
        Personal Information: When you sign up, contact us, or use our services, we may collect your phone number, email address, and other details you provide.
        
        Usage Data: We automatically collect information such as IP addresses, browser type, pages visited, and interactions with our website.
        
        Cookies & Tracking Technologies: We use cookies and similar tracking technologies to enhance user experience and analyze website traffic. You can adjust your cookie preferences in your browser settings.
        
        2. How We Use Your Information
        
        We use the collected information for:
        
        Providing, maintaining, and improving our services
        
        Personalizing user experience
        
        Responding to inquiries and customer support requests
        
        Analyzing website performance and user behavior
        
        Ensuring security
        
        3. Sharing of Information
        
        We do not sell or rent your personal information. However, we may share information with:
        
        Service Providers: Third-party vendors who assist in website operations (e.g., hosting, analytics, payment processing)
        
        Legal Compliance: If required by law, we may disclose information to comply with legal obligations or protect our rights
        
        4. Data Security
        
        We implement security measures to protect your personal information. However, no online service is completely secure, and we cannot guarantee absolute security.
        
        5. Third-Party Links
        
        Our website may contain links to third-party sites. We are not responsible for their privacy practices, and we encourage you to review their policies.
        
        6. Your Rights & Choices
        
        Depending on your location, you may have rights to:
        
        Access, update, or delete your personal data
        
        Opt out of certain data processing activities
    
        To exercise your rights, contact us at <a href="shuffler@gmail.com">shuffler@gmail.com</a>.
        
        7. Changes to This Privacy Policy
        
        We may update this policy from time to time. Any changes will be posted on this page with an updated effective date.
        
        8. Contact Us
        
        If you have any questions about this Privacy Policy, please contact us at <a href="shuffler@gmail.com">shuffler@gmail.com</a>.
        
        By using Shuffler, you agree to this Privacy Policy. Thank you for trusting us!</p>

        <footer>
        <div class="footer-content">
                <ul>
                    <li><a href="shufflerAbout.php">About</a></li>
                    <li><a href="shufflersos@gmail.com">Support: shufflersos@gmail.com</a></li>
                    <li><a href="shuffler_privacy.html">Privacy Policy</a></li>
                    <li><a href="shuffler_terms.html">Terms of Service</a></li>
                </ul>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Shuffler. All rights reserved.</p>
        </div>
    </footer>

        <script src="shuffler.js"></script>
        <script src="shufflerPHP.js"></script>
    </body>
</html>