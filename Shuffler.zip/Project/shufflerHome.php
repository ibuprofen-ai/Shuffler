<?php
include ('connectShuffler.php'); //connects to the database
session_start(); //Starts session

error_reporting(E_ALL); //displays all errors
ini_set('display_errors', 1); //displays all errors

if(isset($_POST['signIn'])){ //if the sign in button is clicked
    $uname=$_POST['uname']; //stores the username entered
    $password=$_POST['pass']; //stores the password entered
    $password = password_hash($password, PASSWORD_DEFAULT); //encrypts the password
    $email=$_POST['email']; //stores the email entered
    $num=$_POST['num']; //stores the number entered


    $check="SELECT * FROM `loginShuffler`  
    WHERE username='$uname'"; //checks if the username and password are in the database
    $result=$conn->query($check); //executes the query
    if ($result->num_rows > 0) { //if the username and password are in the database then the user is signed in and values are stored in the session
        $_SESSION['uname']=$uname;
        $_SESSION['pass']=$password;
        $_SESSION['email']=$email;
        $_SESSION['num']=$num;
        echo "Signed In";
    } else { //if the username and password are not in the database then the user is signed up
        $insert="INSERT INTO `loginShuffler`(`username`, `password`, `email`, `number`) 
        VALUES ('$uname', '$password', '$email', '$num')"; //inserts the username, password, email, and number into the database
        if ($conn->query($insert) === TRUE) { 
            $_SESSION['uname'] = $uname;
            $_SESSION['pass'] = $password; 
            $_SESSION['email'] = $email;
            $_SESSION['num'] = $num;
            echo "Signed Up";
        } else {
            echo "Error: " . $insert . "<br>" . $conn->error;
        }
    }
}
?>

<html lang="en"> <!--language of the page-->
<head> 

    <meta charset="UTF-8"> <!--character set-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--viewport for responsiveness-->
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> <!--compatible with internet explorer-->
    <title>Shuffler</title> <!--title of the page-->
    <link rel="stylesheet" href="shuffler.css"> <!--link to the css file-->
    
</head>
<body> 
    <header> 
        <div id="logo-div">
        <img id="logo" src="Images/Shuffler.png" alt="Logo"> <!--logo of the page-->
        <h1>Shuffler</h1>
        </div>
        <nav> <!--navigation bar linking to other pages-->
            <a href="shufflerHome.php">Home</a> 
            <a href="shufflerAccount.php">Account</a>
            <a href="shufflerAbout.php">How It Works</a>
            <a href="shufflersos@gmail.com">Contact/Support</a>
        </nav>
        <form id="logout-form" action="shufflerLogout.php" method="post">
            <button type="submit" name="signOut" id="sign_out">Sign Out</button> <!--sign out button-->
        </form>
    </header>

    <br>

    <!-- Genres Section -->
    <h3>Genres</h3>
    <div id="genres">
        <button id="rap" value="Rap">Rap</button>
        <div id="rap-buttons">
            <button id="trap" value="Trap">Trap</button>
            <button id="drill" value="Drill">Drill</button>
            <button id="poprap" value="Pop Rap">Pop Rap</button>
            <button id="lyrical" value="Lyrical">Lyrical</button>
            <button id="boombap" value="Boom Bap">Boom Bap</button>
            <button id="gangster" value="Gangster">Gangster</button>
            <button id="emo" value="Emo">Emo</button>
        </div>

        <button id="rock" value="Rock">Rock</button>
        <div id="rock-buttons">
            <button id="classic-rock" value="Classic Rock">Classic Rock</button>
            <button id="hard" value="Hard Rock">Hard Rock</button>
            <button id="punk" value="Punk Rock">Punk Rock</button>
            <button id="progressive" value="Progressive Rock">Progressive Rock</button>
            <button id="alt" value="Alt Rock">Alt Rock</button>
            <button id="indie" value="Indie Rock">Indie Rock</button>
        </div>

        <button id="metal" value="Metal">Metal</button>
        <div id="metal-buttons">
            <button id="nu" value="Nu Metal">Nu Metal</button>
            <button id="heavymetal" value="Heavy Metal">Heavy Metal</button>
            <button id="metalcore" value="Metalcore">Metalcore</button>
            <button id="death" value="Death Metal">Death Metal</button>
            <button id="thrash" value="Thrash Metal">Thrash Metal</button>
            <button id="groove" value="Groove Metal">Groove Metal</button>
        </div>

        <button id="pop" value="Pop">Pop</button>
        <div id="pop-buttons">
            <button id="traditional" value="Traditional Pop">Traditional Pop</button>
            <button id="dance" value="Dance Pop">Dance Pop</button>
            <button id="electro" value="Electro Pop">Electro Pop</button>
            <button id="kpop" value="K-Pop">K-Pop</button>
            <button id="jpop" value="J-Pop">J-Pop</button>
            <button id="poprock" value="Pop Rock">Pop Rock</button>
        </div>

        <button id="rb" value="R&B">R&B</button>
        <div id="rb-buttons">
            <button id="classicrb" value="Classic R&B">Classic R&B</button>
            <button id="contemporary" value="Contemporary R&B">Contemporary R&B</button>
            <button id="soul" value="Soul">Soul</button>
            <button id="hiphop" value="Hip-Hop R&B">Hip-Hop R&B</button>
            <button id="funk" value="Funk">Funk</button>
        </div>
    </div>

    <br>
    <hr>
    <br>

    <!-- Moods Section -->
    <h3>Moods</h3>
    <div id="moods">
        <button id="happy" value="Happy">Happy</button>
        <button id="sad" value="Sad">Sad</button>
        <button id="angry" value="Angry">Angry</button>
        <button id="workout" value="Work Out">Work-Out</button>
        <button id="love" value="Love">Love</button>
        <button id="breakup" value="Breakup">Break-Up</button>
        <button id="weird" value="Weird">Weird</button>
        <button id="energetic" value="Energetic">Energetic</button>
    </div>

    <br>
    <hr>
    <br>

    <!--Shuffle Button-->
    <div id="shuffler">
    <button id="shuffle" onclick="">Shuffle</button>
    </div>

    <div id="song-display">
            <p id="song-title">Song Title</p>

            <iframe id="spotify-player" style="border-radius:12px" src="" 
            width="100%" height="152" frameBorder="0" allowfullscreen="" 
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
            loading="lazy"></iframe> <!--spotify player-->

            <button id="next" name="next">Next</button>
        </div>
    </div>

    <br>

    <!--Footer-->
    <footer>
        <div class="footer-content">
                <ul>
                    <li><a href="shufflerAbout.php">About</a></li>
                    <li><a href="shufflersos@gmail.com">Support: shufflersos@gmail.com</a></li>
                    <li><a href="shuffler_privacy.html">Privacy Policy</a></li>
                    <li><a href="shuffler_terms.html">Terms of Service</a></li>
                </ul>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Shuffler. All rights reserved.</p>
        </div>
    </footer>

    <script src="shuffler.js"></script> <!--javascript file that handles dropdown menus and shuffling-->
    <script src=shufflerPHP.js></script> <!--javascript file that handles php functions-->
</body>
</html>