<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>shuffler_privacy</title>
    <link rel="stylesheet" href="shuffler.css">
</head>
<body>
    <header>
        <div id="logo-div">
        <img id="logo" src="Images/Shuffler.png" alt="Logo">
        <h1>Shuffler</h1>
        </div>
        <nav>
            <a href="shufflerHome.php">Home</a>
            <a href="shufflerAccount.php">Account</a>
            <a href="shufflerAbout.php">How It Works</a>
            <a href="shufflersos@gmail.com">Contact/Support</a>
        </nav>
        <form id="logout-form" action="shufflerLogout.php" method="post">
            <button type="submit" name="signOut" id="sign_out">Sign Out</button>
        </form>
    </header>

    <h1 class="terms">Terms of Service</h1>
    <p class="terms">
        Welcome to Shuffler! These Terms of Service govern your use of our website and services ("Shuffler," "we," "our," or "us"). By accessing or using Shuffler, you agree to comply with these Terms. If you do not agree, please refrain from using our website.

        1. Use of Our Services
        
        You agree to use our website only for lawful purposes and in accordance with these Terms.
        
        We reserve the right to suspend or terminate your access if you violate any policies.
        
        2. Account Registration
        
        Some features may require account registration. You agree to provide accurate and up-to-date information.
        
        You are responsible for maintaining the security of your account credentials.
        
        Shuffler is not responsible for unauthorized access due to your failure to secure your account.
        
        3. User Content
        
        You retain ownership of any content you submit, but you grant Shuffler a non-exclusive, royalty-free license to use it as necessary to provide our services.
        
        You agree not to post illegal, offensive, or harmful content.
        
        We reserve the right to remove any content that violates these Terms.
        
        4. Prohibited Activities
        
        You may not:
        
        Use our website for fraudulent, harmful, or unlawful activities.
        
        Interfere with or disrupt our services, including hacking or attempting to bypass security measures.
        
        Copy, modify, or distribute our content without permission.
        
        5. Intellectual Property
        
        All content on Shuffler, including text, graphics, logos, and software, is our property or used with permission.
        
        You may not use our trademarks or branding without written consent.
        
        6. Disclaimers & Limitation of Liability
        
        Shuffler is provided "as is" without warranties of any kind.
        
        We do not guarantee that our services will be error-free or uninterrupted.
        
        To the maximum extent permitted by law, we are not liable for any direct, indirect, or incidental damages resulting from your use of our website.
        
        7. Termination
        
        We may suspend or terminate your access to Shuffler at our discretion if you violate these Terms.
        
        You may stop using our services at any time.
        
        8. Changes to These Terms
        
        We may update these Terms from time to time. Continued use of our services after changes means you accept the revised Terms.
        
        9. Governing Law
        
        These Terms are governed by the laws of the United States of America. Any disputes will be resolved in the courts of the United States of America.
        
        10. Contact Us
        
        For any questions about these Terms, please contact us at <a href="shuffler@gmail.com">shuffler@gmail.com</a>.
        
        By using Shuffler, you acknowledge and agree to these Terms of Service. Thank you for being a part of our community!
        
        </p>

        <footer>
        <div class="footer-content">
                <ul>
                    <li><a href="shufflerAbout.php">About</a></li>
                    <li><a href="shufflersos@gmail.com">Support: shufflersos@gmail.com</a></li>
                    <li><a href="shuffler_privacy.html">Privacy Policy</a></li>
                    <li><a href="shuffler_terms.html">Terms of Service</a></li>
                </ul>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Shuffler. All rights reserved.</p>
        </div>
    </footer>

        <script src="shuffler.js"></script>
        <script src="shufflerPHP.js"></script>
    </body>
</html>