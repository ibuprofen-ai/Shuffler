// Dropdown 
document.addEventListener('DOMContentLoaded', () => { // Wait for the DOM to load
    document.querySelectorAll('#genres > button').forEach(button => { // Select all genre buttons
        button.addEventListener('click', () => { // Add an event listener to each button
            const subgenre = document.getElementById(`${button.id}-buttons`); // Get the subgenre dropdown
            if (subgenre) {
                subgenre.style.display = subgenre.style.display === 'none' ? 'block' : 'none'; // Toggle the display of the subgenre dropdown if it exists
            }
        });
    });
});

// Arrays of songs for each genre and mood

// Rap Subgenres
let trapSongs = [
    {title: "Bad and Boujee - Migos", url: "https://open.spotify.com/embed/track/0M9ydKzuF3oZTfYYPfaGX1?utm_source=generator"},
    {title: "Monster - Future", url: "https://open.spotify.com/embed/track/4NeioZ97QrelO02IXj4uYf?utm_source=generator"},
    {title: "XO TOUR Llif3 - Lil Uzi Vert", url: "https://open.spotify.com/embed/track/7GX5flRQZVHRAGd6B4TmDO?utm_source=generator&theme=0"}
];

let drillSongs = [
    {title: "Love Sosa - Chief Keef", url: "https://open.spotify.com/embed/track/01Lr5YepbgjXAWR9iOEyH1?utm_source=generator"},
    {title: "Dior - Pop Smoke", url: "https://open.spotify.com/embed/track/79s5XnCN4TJKTVMSmOx8Ep?utm_source=generator"},
    {title: "Crazy Story, Pt.3 - King Von", url: "https://open.spotify.com/embed/track/23TwR29GSeJBfXnXhmDlwR?utm_source=generator"}
];

let popRapSongs = [
    {title: "Hotline Bling - Drake", url: "https://open.spotify.com/embed/track/0wwPcA6wtMf6HUMpIRdeP7?utm_source=generator"},
    {title: "The Hills - The Weeknd", url: "https://open.spotify.com/embed/track/7fBv7CLKzipRk6EC6TWHOB?utm_source=generator"},
    {title: "Hey Ya! - OutKast", url: "https://open.spotify.com/embed/track/2PpruBYCo4H7WOBJ7Q2EwM?utm_source=generator"}
];

let lyricalSongs = [
    {title: "Stan - Eminem", url: "https://open.spotify.com/embed/track/3UmaczJpikHgJFyBTAJVoz?utm_source=generator"},
    {title: "Sing About Me, I'm Dying of Thirst - Kendrick Lamar", url: "https://open.spotify.com/embed/track/3q2v8QaTnHLveAQzR6gvYm?utm_source=generator"},
    {title: "Megaman - Lil Wayne", url: "https://open.spotify.com/embed/track/66TxPMqbyDLJOusYH4o93n?utm_source=generator"}
];

let boomBapSongs = [
    {title: "Shook Ones, Pt.II - Mobb Deep", url: "https://open.spotify.com/embed/track/33ZXjLCpiINn8eQIDYEPTD?utm_source=generator"},
    {title: "N.Y. State of Mind - Nas", url: "https://open.spotify.com/embed/track/0trHOzAhNpGCsGBEu7dOJo?utm_source=generator"},
    {title: "C.R.E.A.M. - Wu-Tang Clan", url: "https://open.spotify.com/embed/track/119c93MHjrDLJTApCVGpvx?utm_source=generator"}
];

let gangsterRapSongs = [
    {title: "Straight Outta Compton - N.W.A", url: "https://open.spotify.com/embed/track/6KIKRz9eSTXdNsGUnomdtW?utm_source=generator"},
    {title: "Can't C Me - 2Pac", url: "https://open.spotify.com/embed/track/7rUchbZxrhF29Q0vYjKEU0?utm_source=generator"},
    {title: "Gin and Juice - Snoop Dogg", url: "https://open.spotify.com/embed/track/39QBkWKnap8wRSW4WB9OK0?utm_source=generator"}
];

let emoRapSongs = [
    {title: "Lucid Dreams - Juice WRLD", url: "https://open.spotify.com/embed/track/285pBltuF7vW8TeWk8hdRR?utm_source=generator"},
    {title: "Revenge - XXXTentacion", url: "https://open.spotify.com/embed/track/5TXDeTFVRVY7Cvt0Dw4vWW?utm_source=generator"},
    {title: "Awful Things - Lil Peep", url: "https://open.spotify.com/embed/track/77qveRnReN3HaFrikk58nB?utm_source=generator"}
];

//Rock Subgenres
let classicRockSongs = [
    {title: "Comfortably Numb - Pink Floyd", url: "https://open.spotify.com/embed/track/5HNCy40Ni5BZJFw1TKzRsC?utm_source=generator"},
    {title: "Fat Bottomed Girls - Queen", url: "https://open.spotify.com/embed/track/4igIYHF3B5VBxEafHauVo3?utm_source=generator"},
    {title: "Separate Ways (Worlds Apart) - Journey", url: "https://open.spotify.com/embed/track/1pTw2cNrp9L3esxLAvWnN2?utm_source=generator"}
];

let hardRockSongs = [
    {title: "Dirty Deeds Done Dirt Cheap - AC/DC", url: "https://open.spotify.com/embed/track/2d4e45fmUnguxh6yqC7gNT?utm_source=generator"},
    {title: "Enter Sandman - Metallica", url: "https://open.spotify.com/embed/track/3VqHuw0wFlIHcIPWkhIbdQ?utm_source=generator"},
    {title: "Crazy Train - Ozzy Osbourne", url: "https://open.spotify.com/embed/track/7ACxUo21jtTHzy7ZEV56vU?utm_source=generator"}
];

let punkRockSongs = [
    {title: "Basket Case - Green Day", url: "https://open.spotify.com/embed/track/6L89mwZXSOwYl76YXfX13s?utm_source=generator"},
    {title: "Decode - Paramore", url: "https://open.spotify.com/embed/track/1ZLtE9tSJdaUiIJ9YoKHQe?utm_source=generator"},
    {title: "King for a Day - Pierce the Veil", url: "https://open.spotify.com/embed/track/1IT0WQk5J8NsaeII8ktdlZ?utm_source=generator"}
];

let progressiveRockSongs = [
    {title: "Roundabout - Yes", url: "https://open.spotify.com/embed/track/466C6kwoJHLUJ8VHG98hCY?utm_source=generator"},
    {title: "Stairway to Heaven - Led Zeppelin", url: "https://open.spotify.com/embed/track/5CQ30WqJwcep0pYcV4AMNc?utm_source=generator"},
    {title: "Bohemian Rhapsody - Queen", url: "https://open.spotify.com/embed/track/7tFiyTwD0nx5a1eklYtX2J?utm_source=generator"}
];

let altRockSongs = [
    {title: "Smells Like Teen Spirit - Nirvana", url: "https://open.spotify.com/embed/track/5ghIJDpPoe3CfHMGu71E6T?utm_source=generator"},
    {title: "Black Hole Sun - Soundgarden", url: "https://open.spotify.com/embed/track/2EoOZnxNgtmZaD8uUmz2nD?utm_source=generator"},
    {title: "Karma Police - Radiohead", url: "https://open.spotify.com/embed/track/63OQupATfueTdZMWTxW03A?utm_source=generator"}
];

let indieRockSongs = [
    {title: "Brand New City - Mitski", url: "https://open.spotify.com/embed/track/47k7FCxk7ylTwKCnJ3QTVc?utm_source=generator"},
    {title: "Duvet - boa", url: "https://open.spotify.com/embed/track/42qNWdLKCI41S4uzfamhFM?utm_source=generator"},
    {title: "Somebody Told Me - The Killers", url: "https://open.spotify.com/embed/track/6PwjJ58I4t7Mae9xfZ9l9v?utm_source=generator"}
];

// Metal Subgenres
let nuMetalSongs = [
    {title: "Freak on a Leash - Korn", url: "https://open.spotify.com/embed/track/6W21LNLz9Sw7sUSNWMSHRu?utm_source=generator"},
    {title: "Numb - Linkin Park", url: "https://open.spotify.com/embed/track/2nLtzopw4rPReszdYBJU6h?utm_source=generator"},
    {title: "Before I Forget - Slipknot", url: "https://open.spotify.com/embed/track/6wqJeItl3Vc3az4ZicSQAB?utm_source=generator"}
];

let heavyMetalSongs = [
    {title: "War Pigs - Black Sabbath", url: "https://open.spotify.com/embed/track/0HVQuuXGAcQ2P5mBN521ae?utm_source=generator"},
    {title: "The Trooper - Iron Maiden", url: "https://open.spotify.com/embed/track/2C3B3dva983HPMojFqWLOp?utm_source=generator"},
    {title: "Rainbow in the Dark - Dio", url: "https://open.spotify.com/embed/track/2PpNgmrS9mAyrkRAwn6YPq?utm_source=generator"}
];

let metalcoreSongs = [
    {title: "Tears Don't Fall - Bullet for My Valentine", url: "https://open.spotify.com/embed/track/1kdiiFGX1Htx0aVZYaDwEJ?utm_source=generator"},
    {title: "Diary of Jane - Breaking Benjamin", url: "https://open.spotify.com/embed/track/0faXHILILebCGnJBPU6KJJ?utm_source=generator"},
    {title: "I Don't Care - Violent Vira", url: "https://open.spotify.com/embed/track/3RzYbj6Rr6mSJCar4Ua86F?utm_source=generator"}
];

let deathMetalSongs = [
    {title: "Symbolic - Death", url: "https://open.spotify.com/embed/track/0dpFb4qv92TE9R00Lq4SAW?utm_source=generator"},
    {title: "Scream Bloody Gore - Death", url: "https://open.spotify.com/embed/track/1AOhYQVuJxwRk0l54O1Ig6?utm_source=generator"},
    {title: "Crystal Mountain - Death", url: "https://open.spotify.com/embed/track/0ItAcLSkUiePOmFGun3cSe?utm_source=generator"}
];

let thrashMetalSongs = [
    {title: "Angel of Death - Slayer", url: "https://open.spotify.com/embed/track/5ohfpKB5tt275f4Y4lQ9F7?utm_source=generator"},
    {title: "Master of Puppets - Metallica", url: "https://open.spotify.com/embed/track/54bm2e3tk8cliUz3VSdCPZ?utm_source=generator"},
    {title: "Peace Sells - Megadeth", url: "https://open.spotify.com/embed/track/5a2hIQWInPjqkkFiUEgxoX?utm_source=generator"}
];

let grooveMetalSongs = [
    {title: "10's - Pantera", url: "https://open.spotify.com/embed/track/5qG4mrKUlmGce1FA4wGrr7?utm_source=generator"},
    {title: "Du Hast - Rammstein", url: "https://open.spotify.com/embed/track/6uEvFCaOqXyEidoO8BZbyh?utm_source=generator"},
    {title: "I Am the Storm - Crowbar", url: "https://open.spotify.com/embed/track/1X1LBsy1On0sZbBQqw2r3O?utm_source=generator"}
];

// Pop Subgenres
let traditionalPopSongs = [
    {title: "Fly Me to the Moon - Frank Sinatra", url: "https://open.spotify.com/embed/track/7FXj7Qg3YorUxdrzvrcY25?utm_source=generator"},
    {title: "Can't Help Falling in Love - Elvis Presley", url: "https://open.spotify.com/embed/track/44AyOl4qVkzS48vBsbNXaC?utm_source=generator"},
    {title: "The Way You Look Tonight - Frank Sinatra", url: "https://open.spotify.com/embed/track/0elmUoU7eMPwZX1Mw1MnQo?utm_source=generator"}
];

let dancePopSongs = [
    {title: "Good in Bed - Dua Lipa", url: "https://open.spotify.com/embed/track/6uAFJ75WDAoAPyCWJAtvks?utm_source=generator"},
    {title: "Party in the U.S.A. - Miley Cyrus", url: "https://open.spotify.com/embed/track/5Q0Nhxo0l2bP3pNjpGJwV1?utm_source=generator"},
    {title: "Just Dance - Lady Gaga", url: "https://open.spotify.com/embed/track/2x7MyWybabEz6Y6wvHuwGE?utm_source=generator"}
];

let electroPopSongs = [
    {title: "Take On Me - A-ha", url: "https://open.spotify.com/embed/track/2WfaOiMkCvy7F5fcp2zZ8L?utm_source=generator"},
    {title: "Midnight Sky - Miley Cyrus", url: "https://open.spotify.com/embed/track/4i2qxFEVVUi8yOYoxB8TCX?utm_source=generator"},
    {title: "Espresso - Sabrina Carpenter", url: "https://open.spotify.com/embed/track/2HRqTpkrJO5ggZyyK6NPWz?utm_source=generator"}
];

let kPopSongs = [
    {title: "Dynamite - BTS", url: "https://open.spotify.com/track/4samlXSYWsKiGEUwlAFkGE"},
    {title: "Gangnam Style - Psy", url: "https://open.spotify.com/track/3VCSq20jDj7Pmy4riWbUl4"},
    {title: "Fancy - Twice", url: "https://open.spotify.com/track/3eeJRjkfBMjWkKD5KkPnSN"}
];

let jPopSongs = [
    {title: "Blue Bird - Ikimonogakari", url: "https://open.spotify.com/embed/track/2XpV9sHBexcNrz0Gyf3l18?utm_source=generator"},
    {title: "Stay With Me - Miki Matsubara", url: "https://open.spotify.com/embed/track/2BHj31ufdEqVK5CkYDp9mA?utm_source=generator"},
    {title: "Plastic Love - Mariya Takeuchi", url: "https://open.spotify.com/embed/track/7rU6Iebxzlvqy5t857bKFq?utm_source=generator"}
];

let popRockSongs = [
    {title: "Don't Stop Believin' - Journey", url: "https://open.spotify.com/embed/track/77NNZQSqzLNqh2A9JhLRkg?utm_source=generator"},
    {title: "Africa - Toto", url: "https://open.spotify.com/embed/track/2374M0fQpWi3dLnB54qaLX?utm_source=generator"},
    {title: "Shut Up and Dance - Walk the Moon", url: "https://open.spotify.com/embed/track/64QftS2rGzpynevjuCsJXW?utm_source=generator"}
];

// R&B Subgenres
let classicRBSongs = [
    {title: "What's Going On - Marvin Gaye", url: "https://open.spotify.com/embed/track/3Um9toULmYFGCpvaIPFw7l?utm_source=generator"},
    {title: "Respect - Aretha Franklin", url: "https://open.spotify.com/embed/track/7s25THrKz86DM225dOYwnr?utm_source=generator"},
    {title: "Sexual Healing - Marvin Gaye", url: "https://open.spotify.com/embed/track/3VZmChrnVW8JK6ano4gSED?utm_source=generator"}
];

let contemporaryRBSongs = [
    {title: "Thinkin Bout You - Frank Ocean", url: "https://open.spotify.com/embed/track/7DfFc7a6Rwfi3YQMRbDMau?utm_source=generator"},
    {title: "Best Part - Daniel Caesar", url: "https://open.spotify.com/embed/track/1RMJOxR6GRPsBHL8qeC2ux?utm_source=generator"},
    {title: "Adore - Prince", url: "https://open.spotify.com/embed/track/7tyckyaQOzlsTjnujLinRt?utm_source=generator"}
];

let soulSongs = [
    {title: "At Last - Etta James", url: "https://open.spotify.com/embed/track/4Hhv2vrOTy89HFRcjU3QOx?utm_source=generator"},
    {title: "I'd Rather Go Blind - Etta James", url: "https://open.spotify.com/embed/track/1kPBT8S2wJFNAyBMnGVZgL?utm_source=generator"},
    {title: "Try a Little Tenderness - Otis Redding", url: "https://open.spotify.com/embed/track/36AlMHDBFwSsD3FQOy1R81?utm_source=generator"}
];

let hiphopRBSongs = [
    {title: "No Diggity - Blackstreet", url: "https://open.spotify.com/embed/track/6MdqqkQ8sSC0WB4i8PyRuQ?utm_source=generator"},
    {title: "U Got It Bad - Usher", url: "https://open.spotify.com/embed/track/7J41dYQolQJEtj3UmKLu5r?utm_source=generator"},
    {title: "Sidewalks - The Weeknd", url: "https://open.spotify.com/embed/track/4h90qkbnW1Qq6pBhoPvwko?utm_source=generator"}
];

let funkSongs = [
    {title: "Get Down On It - Kool & The Gang", url: "https://open.spotify.com/embed/track/4Cv6ongCvJy9JfSkWVnb5D?utm_source=generator"},
    {title: "Superstition - Stevie Wonder", url: "https://open.spotify.com/embed/track/1h2xVEoJORqrg71HocgqXd?utm_source=generator"},
    {title: "i - Kendrick Lamar", url: "https://open.spotify.com/embed/track/7wdzLe2Gsx1RGqbvYZHASz?utm_source=generator"}
];

// Mood Songs
let happy = [
    {title: "Happy - Pharrell Williams", url: "https://open.spotify.com/embed/track/60nZcImufyMA1MKQY3dcCH?utm_source=generator"},
    {title: "I Gotta Feeling - Black Eyed Peas", url: "https://open.spotify.com/embed/track/2H1047e0oMSj10dgp7p2VG?utm_source=generator"},
    {title: "Walking on Sunshine - Katrina and the Waves", url: "https://open.spotify.com/embed/track/05wIrZSwuaVWhcv5FfqeH0?utm_source=generator"}
];

let sad = [
    {title: "Someone Like You - Adele", url: "https://open.spotify.com/embed/track/1zwMYTA5nlNjZxYrvBB2pV?utm_source=generator"},
    {title: "Tears in Heaven - Eric Clapton", url: "https://open.spotify.com/embed/track/1kgdslQYmeTR4thk9whoRw?utm_source=generator"},
    {title: "The Sound of Silence - Simon and Garfunkel", url: "https://open.spotify.com/embed/track/3YfS47QufnLDFA71FUsgCM?utm_source=generator"}
];

let angry = [
    {title: "Break Stuff - Limp Bizkit", url: "https://open.spotify.com/embed/track/5cZqsjVs6MevCnAkasbEOX?utm_source=generator"},
    {title: "Killing in the Name - Rage Against the Machine", url: "https://open.spotify.com/embed/track/3FUS56gKr9mVBmzvlnodlh?utm_source=generator"},
    {title: "Fuck You - CeeLo Green", url: "https://open.spotify.com/embed/track/4ycLiPVzE5KamivXrAzGFG?utm_source=generator"}
];

let workout = [
    {title: "Stronger - Kanye West", url: "https://open.spotify.com/embed/track/0j2T0R9dR9qdJYsB7ciXhf?utm_source=generator"},
    {title: "Eye of the Tiger - Survivor", url: "https://open.spotify.com/embed/track/2KH16WveTQWT6KOG9Rg6e2?utm_source=generator"},
    {title: "Power - Kanye West", url: "https://open.spotify.com/embed/track/2KH16WveTQWT6KOG9Rg6e2?utm_source=generator"}
];

let love = [
    {title: "All of Me - John Legend", url: "https://open.spotify.com/embed/track/3U4isOIWM3VvDubwSI3y7a?utm_source=generator"},
    {title: "Perfect - Ed Sheeran", url: "https://open.spotify.com/embed/track/0tgVpDi06FyKpA1z0VMD4v?utm_source=generator"},
    {title: "Adore You - Juice WRLD", url: "https://open.spotify.com/embed/track/38VkGQ4Sumz99xja6TCs7z?utm_source=generator"}
];

let breakup = [
    {title: "Fuck Love - XXXTentacion", url: "https://open.spotify.com/embed/track/7AQim7LbvFVZJE3O8TYgf2?utm_source=generator"},
    {title: "Before He Cheats - Carrie Underwood", url: "https://open.spotify.com/embed/track/0ZUo4YjG4saFnEJhdWp9Bt?utm_source=generator"},
    {title: "If You Can't Hang - Sleeping With Sirens", url: "https://open.spotify.com/embed/track/2Tc9VznHtQUmfOgE3L1RdN?utm_source=generator"}
];

let weird = [
    {title: "Closer - Nine Inch Nails", url: "https://open.spotify.com/embed/track/5mc6EyF1OIEOhAkD0Gg9Lc?utm_source=generator"},
    {title: "Psycho Killer - Talking Heads", url: "https://open.spotify.com/embed/track/7dSCxR4LqkmxoBrq9MzVSD?utm_source=generator"},
    {title: "Buddy Holly - Weezer", url: "https://open.spotify.com/embed/track/3mwvKOyMmG77zZRunnxp9E?utm_source=generator"}
];

let energetic = [
    {title: "Don't Stop Me Now - Queen", url: "https://open.spotify.com/embed/track/7hQJA50XrCWABAu5v6QZ4i?utm_source=generator"},
    {title: "SICKO MODE - Travis Scott", url: "https://open.spotify.com/embed/track/2xLMifQCjDGFmkHkpNLD9h?utm_source=generator"},
    {title: "Take a Step Back - Ski Mask the Slump God", url: "https://open.spotify.com/embed/track/2gQYziDV5cSTRSqr6akzi5?utm_source=generator"}
];

const songCategories = { // Object containing all song categories
    // Rap Subgenres
    'trap': trapSongs, 
    'drill': drillSongs, 
    'poprap': popRapSongs,
    'lyrical': lyricalSongs,
    'boombap': boomBapSongs,
    'gangster': gangsterRapSongs,
    'emo': emoRapSongs,

    // Rock Subgenres
    'classic-rock': classicRockSongs,
    'hard': hardRockSongs,
    'punk': punkRockSongs,
    'progressive': progressiveRockSongs,
    'alt': altRockSongs,
    'indie': indieRockSongs,

    // Metal Subgenres
    'nu': nuMetalSongs,
    'heavymetal': heavyMetalSongs,
    'metalcore': metalcoreSongs,
    'death': deathMetalSongs,
    'thrash': thrashMetalSongs,
    'groove': grooveMetalSongs,

    // Pop Subgenres
    'traditional': traditionalPopSongs,
    'dance': dancePopSongs,
    'electro': electroPopSongs,
    'kpop': kPopSongs,
    'jpop': jPopSongs,
    'poprock': popRockSongs,

    // R&B Subgenres
    'classicrb': classicRBSongs,
    'contemporary': contemporaryRBSongs,
    'soul': soulSongs,
    'hiphop': hiphopRBSongs,
    'funk': funkSongs,

    // Mood Songs
    'happy': happy,
    'sad': sad,
    'angry': angry,
    'workout': workout,
    'love': love,
    'breakup': breakup,
    'weird': weird,
    'energetic': energetic

};

// Song Selection Buttons
document.addEventListener('DOMContentLoaded', () => { // Wait for the DOM to load
    function Selection(containerSelector) { // Function to handle button selection
        const containers = document.querySelectorAll(containerSelector); // Select all containers
        containers.forEach(container => { // Loop through each container
            container.addEventListener('click', (event) => { // Add an event listener to each container
                if (event.target.tagName === 'BUTTON') { // Check if the clicked element is a button
                    container.querySelectorAll('button').forEach(btn => { // Loop through each button in the container
                        btn.classList.remove('selected'); // Remove 'selected' from each button
                    });
                    event.target.classList.add('selected'); // Add 'selected' to clicked button
                }
            });
        });
    } 
    Selection('#genres, #moods'); // Call the Selection function for both genres and moods
});

// Shuffle Button
document.getElementById("shuffle").addEventListener("click", function() { // Add an event listener to the shuffle button
    
    const selectedGenre = document.querySelector('#genres .selected'); // Get the selected genre
    const selectedMood = document.querySelector('#moods .selected'); // Get the selected mood

    if (!selectedGenre && !selectedMood) { // Check if no genre or mood is selected
        alert("Please select a genre or mood before shuffling!"); // Alert the user to select a genre or mood
        return; // Exit the function
    }

    let songList = []; // Create an empty array to store the selected song list

    if (selectedGenre && songCategories && songCategories[selectedGenre.id]) { // Check if a genre is selected and the genre exists in the songCategories object
        songList = songCategories[selectedGenre.id]; // Set the songList to the selected genre
    } else if (selectedMood && songCategories && songCategories[selectedMood.id]) { // Check if a mood is selected and the mood exists in the songCategories object
        songList = songCategories[selectedMood.id]; // Set the songList to the selected mood
    }

    if (songList.length > 0) { // Check if there are songs in the selected category
        const song = songList[Math.floor(Math.random() * songList.length)]; // Select a random song from the songList

        if (song && song.title && song.url) { // Check if the song object is valid
            document.getElementById("song-display").style.display = 'block'; // Show the song display
            document.getElementById("song-title").textContent = song.title; // Set the song title
            document.getElementById("spotify-player").src = song.url; // Set the Spotify embed URL
        } else { // If the song object is invalid
            console.error("Invalid song object"); // Log an error
        }
    } else { // If there are no songs in the selected category
        console.error("No songs found in the selected category"); // Log an error
}
});


// Next Button

document.getElementById("next").addEventListener("click", function() { // Same as above, but for the next button

    const selectedGenre = document.querySelector('#genres .selected');
    const selectedMood = document.querySelector('#moods .selected');

    if (!selectedGenre && !selectedMood) {
        alert("Please select a genre or mood before shuffling!");
        return;
    }

    let songList = [];

    if (selectedGenre && songCategories[selectedGenre.id]) {
        songList = songCategories[selectedGenre.id];
    } else if (selectedMood && songCategories[selectedMood.id]) {
        songList = songCategories[selectedMood.id];
    }

    if (songList.length > 0) {
        const song = songList[Math.floor(Math.random() * songList.length)];

        document.getElementById("song-display").style.display='block'; // Show song display
        document.getElementById("song-title").textContent=song.title;
        document.getElementById("spotify-player").src = song.url; // Set the Spotify embed URL
        } else {
            alert("Please select a genre or mood before shuffling.");
        }
});