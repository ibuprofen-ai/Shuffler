<?php 
    include ('connectShuffler.php'); //connects to the database

    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    session_start(); //starts the session

    $uname=$_SESSION['uname']; // Get the logged-in username
    $password=$_SESSION['pass']; //stores the password entered
    $email=$_SESSION['email']; //stores the email entered
    $num=$_SESSION['num']; //stores the number entered

    //Current data
    $query = "SELECT * FROM `loginShuffler` WHERE username='$uname'"; //selects all the data from the database of the logged in user
    $result=$conn->query($query);
    $data=$result->fetch_all(MYSQLI_ASSOC);

    if(isset($_POST['edit'])){ //if the edit button is clicked

        $uname=$_POST['uname']; //stores the username entered
        $password=$_POST['pass']; //stores the password entered
        $email=$_POST['email']; //stores the email entered
        $num=$_POST['num']; //stores the number entered

        //Update button
        if (!empty($uname)) { // Only update the username if it's provided
            $updateUser="UPDATE loginShuffler SET username='$uname' WHERE username='{$_SESSION['uname']}'";
            if($conn->query($updateUser)===TRUE){ //if the query is successful
                echo "Updated Username"; //displays a message
            }else{
                echo "Error: ".$updateUser."<br>".$conn->error; //displays an error message
            }
        }else if (!empty($password)) { // Only update the password if it's provided
            $password=password_hash($password, PASSWORD_DEFAULT);
            $updatePass="UPDATE loginShuffler SET password='$password' WHERE password='{$_SESSION['pass']}'";
            if ($conn->query($updatePass)===TRUE){ //if the query is successful
                echo "Updated Password"; //displays a message
            }else{
                echo "Error: ".$updatePass."<br>".$conn->error; //displays an error message
            }
        }else if (!empty($email)) { // Only update the email if it's provided
            $updateEmail="UPDATE loginShuffler SET email='$email' WHERE email='{$_SESSION['email']}'";
            if($conn->query($updateEmail)===TRUE){ //if the query is successful
                echo "Updated Email"; //displays a message
            }else{ //if the query is not successful
                echo "Error: ".$updateEmail."<br>".$conn->error; //displays an error message
            }
        }else if (!empty($num)) { // Only update the number if it's provided
            $updateNum="UPDATE loginShuffler SET number='$num' WHERE number='{$_SESSION['num']}'";
            if($conn->query($updateNum)===TRUE){ //if the query is successful
                echo "Updated Number"; //displays a message
            }else{ //if the query is not successful
                echo "Error: ".$updateNum."<br>".$conn->error; //displays an error message
            }
        }

        $_SESSION['uname']=$uname; // Update the session username
        $_SESSION['pass']=$password; // Update the session password
        $_SESSION['email']=$email; // Update the session email
        $_SESSION['num']=$num; // Update the session number
        $query="SELECT * FROM `loginShuffler` WHERE username='{$_SESSION['uname']}'";
        $result=$conn->query($query);
        if (!$result) {
            die("Query failed: " . $conn->error); // Debugging output
        }
        $data = $result->fetch_all(MYSQLI_ASSOC);
}

    //Delete account button
    if(isset($_POST['delete'])){ //if the delete button is clicked
        $delete="DELETE FROM loginShuffler WHERE username='{$_SESSION['uname']}'"; //deletes the user
        if($conn->query($delete)===TRUE){ //if the query is successful
            echo "Deleted"; //displays a message
            session_destroy(); //destroys the session
            header("Location: shufflerHome.html"); // Redirect to home
            exit();
        }else{
            echo "Error: ".$delete."<br>".$conn->error; //displays an error message
            $conn->close(); //closes the connection
        }
    }

?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shuffler Account</title>
    <link rel="stylesheet" href="shuffler.css">
</head>
<body>
    <header>
        <div>
            <img id="logo" src="Images/Shuffler.png" alt="Logo">
            <h1>Shuffler</h1>
        </div>
        <nav>
            <a href="shufflerHome.php">Home</a>
            <a href="shufflerAccount.php">Account</a>
            <a href="shufflerAbout.php">How It Works</a>
            <a href="shufflersos@gmail.com">Contact/Support</a>
        </nav>
        <div>
        <form id="logout-form" action="shufflerLogout.php" method="post">
            <button type="submit" name="signOut" id="sign_out">Sign Out</button>
        </form>
        </div>
    </header>

    <main>
        <section id="account-section">
            <h2>Account Details</h2>
            <div id="account-details" name="edit">
                <h3>Current Account Details:</h3>
                <table id="table">
                <tr>
                    <th><u>Username</u></th>
                    <th><u>Email</u></th> 
                    <th><u>Phone Number</u></th>
                </tr>
                <?php foreach($data as $row): ?>
                <tr>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['number']) ?></td>
                </tr>
                <?php endforeach ?>
                </table>
                <form action="shufflerAccount.php" method="post">
                    <label for="uname">Username:</label>
                    <input type="text" id="uname" name="uname" placeholder="User123">
                    <label for="password">Password:</label>
                    <input type="password" id="pass" name="pass">
                    <label for="email">Email:</label>
                    <input type="email" id="email" placeholder="user@example.com" name="email">
                    <label for="num">Phone Number:</label>
                    <input type="tel" id="num" placeholder="123-456-7890" name="num">
                    <button id="edit" name="edit" value="submit">Edit Details</button>
                </form>
            </div>
        </section>

        <br>
        <br>

        <section id="account-actions">
            <h2>Account Actions</h2>
            <div id="actions">
                <form action="shufflerAccount.php" method="post">
                    <button id="delete" name="delete" value="submit">Delete Account</button>
                </form>
        </section>

        <br>
    </main>

    <footer>
        <div class="footer-content">
                <ul>
                    <li><a href="shufflerAbout.php">About</a></li>
                    <li><a href="shufflersos@gmail.com">Support: shufflersos@gmail.com</a></li>
                    <li><a href="shuffler_privacy.html">Privacy Policy</a></li>
                    <li><a href="shuffler_terms.html">Terms of Service</a></li>
                </ul>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Shuffler. All rights reserved.</p>
        </div>
    </footer>

    <script src="shuffler.js"></script>
    <script src="shufflerPHP.js"></script>
</body>
</html>
 