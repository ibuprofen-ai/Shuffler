document.getElementById("sign_in").addEventListener("click", function () { // When the user clicks the sign in button, the form will be displayed
    const form = document.getElementById("sign-in-form"); // The form is hidden by default
    if (form.style.display === "none" || form.style.display === "") { // If the form is hidden
        form.style.display = "block"; // The form will be displayed
    } else { // If the form is displayed
        form.style.display = "none"; // The form will be hidden
    }
});

document.getElementById("sign_out").addEventListener("click", function () { // When the user clicks the sign out button, the form will be sent to shufflerLogout.php
    document.getElementById("sign_Out").action = "shufflerLogout.php";
});