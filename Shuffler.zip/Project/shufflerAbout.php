<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>shuffler_privacy</title>
    <link rel="stylesheet" href="shuffler.css">
</head>
<body>
    <header>
        <div id="logo-div">
        <img id="logo" src="Images/Shuffler.png" alt="Logo">
        <h1>Shuffler</h1>
        </div>
        <nav>
            <a href="shufflerHome.html">Home</a>
            <a href="shufflerAccount.html">Account</a>
            <a href="shufflerAbout.html">How It Works</a>
            <a href="shufflersos@gmail.com">Contact/Support</a>
        </nav>
        <button id="sign_in">Sign In</button>
    </header>

    <form id="sign-in-form" action="shufflerHome.php" method="post" style="display: none;">
        <h1><u>Sign In</u></h1>
        <label for="uname">Username:</label>
        <input type="text" id="uname" placeholder="User123">
        <label for="pass">Password:</label>
        <input type="password" id="pass">
        <label for="email">Email:</label>
        <input type="email" id="email" placeholder="user@example.com">
        <label for="num">Phone Number:</label>
        <input type="tel" id="num" placeholder="123-456-7890">
        <input type="submit" value="Submit">
    </form>
    <h1 class="terms">How it Works</h1>
    <p class="terms">
    
        Shuffler is a music streaming service that allows users to shuffle random songs based on the 
        genre/mood they select. If the user is signed in they can either like or block the song that
        is playing using Spotify's "add to playlist" function and "don't play this artist" or "hide this song" function.
        The user can also skip the song if they do not like it. 
        The user can also view their liked songs and blocked songs playlists. 
        The user can also view their account information and change their password. 
        If the user is not signed in, they can still shuffle songs but they will not be able to 
        like or block songs, unless they are signed into Spotify. Users can delete their account at any time.
        
    </p>

        <!--Footer-->
        <footer>
            <div class="footer-content">
                    <ul>
                        <li><a href="shufflerAbout.php">About</a></li>
                        <li><a href="shufflersos@gmail.com">Support: shufflersos@gmail.com</a></li>
                        <li><a href="shuffler_privacy.html">Privacy Policy</a></li>
                        <li><a href="shuffler_terms.html">Terms of Service</a></li>
                    </ul>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Shuffler. All rights reserved.</p>
            </div>
        </footer>

        <script src="shuffler.js"></script>
        <script src="shufflerPHP.js"></script>
    </body>
</html>